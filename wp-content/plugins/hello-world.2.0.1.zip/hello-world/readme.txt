=== Hello World ===
Contributors: Kau-Boy
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7914504
Tags: hello, dolly, yoda
Tested up to: 5.2.3
Requires PHP: 5.2
Stable tag: 2.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0


In tribute to the famous "Hello Dolly" plugin by Matt Mullenweg comes this new plugin. And how could someone possible name a new default plugin other than "Hello World", as it's THE definition for a default example :)

== Frequently Asked Questions ==

= Can I add my own lyrics? =

Yes, you can! Just create a folder `wp-content/uploads/hello-world-lyrics` and save your lyric file there, with one "quote" per line.

== Change Log ==

= 2.0.1 =

* Make plugin fully translatable

= 2.0.0 =
* New major release enabling custom lyrics saved to `wp-content/uploads/hello-world-lyrics`
* Time invested for this release: 90min

= 1.0.0 =
* First stable release with lyrics for "Hello World", "Yoda quotes" and the original "Hello Dolly" lyrics
* Time invested for this release: 120min