<?php

define( 'STRATA_CORE_VERSION', '1.1' );
define( 'STRATA_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'STRATA_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'STRATA_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'STRATA_CORE_MODULES_PATH', STRATA_CORE_ABS_PATH . '/modules' );
define( 'STRATA_CORE_MODULES_URL_PATH', STRATA_CORE_URL_PATH . 'modules' );